**维护者发布说明：插件0.1.1**

本目录是可独立提交到GitHub的插件来源根目录。现有三个工具包保持独立发布，不从开发工作区自动搬入插件。内含的分析skill是既有0.4.0原样副本，首次配置向导是新增部分。

**对外文件**

| 文件／目录 | 用途 |
| --- | --- |
| `cogneuro-fmri-marketplace-0.1.1.zip` | 完整来源发行包；首次用户解压后添加此来源 |
| `cogneuro-fmri-plugin-0.1.1.zip` | 直接含plugin.json的单插件组件包，供已有来源或其他兼容安装方式集成 |
| 同名`.sha256`文件 | 下载完整性校验 |
| 解压的`cogneuro-fmri-marketplace` | 与本目录对应的干净源码；可提交GitHub |

用户安装插件后不必再单独安装skill ZIP。三个工具包、MATLAB/SPM和所选方法的依赖仍要安装，并由首次配置向导记录路径。

**上传GitHub**

将本目录中的 `.agents`、`plugins`、`scripts`、说明与验证文件提交到 [XindiShu/CogNeuro_fMRI_Sum](https://github.com/XindiShu/CogNeuro_fMRI_Sum) 仓库根目录，尤其要保留隐藏目录 `.agents/plugins/marketplace.json`。不要把整个 `cogneuro-fmri-marketplace` 外层目录嵌套上传，也不要上传整个 `psy_skill` 开发工作区。用户环境档、数据、输出、缓存和日志不属于发行内容。

用户已指定上述仓库，插件的repository/homepage/websiteURL已填写。2026-10-18只读检查时仓库为空，没有可验证的默认分支提交或发布tag；本轮不创建或假定远程tag。源码上传后，可按README中的真实仓库命令添加来源，再按维护者创建的tag固定版本。

本次没有向GitHub推送，也没有提交官方公共目录。GitHub来源、本地来源和官方公共目录是不同的分发途径；前两者不要求先通过官方目录审核。相应客户端或组织策略仍须允许第三方来源。

**许可证**

本次封装没有替作者选择项目许可证，也没有虚构作者身份。确定自有内容的授权方式和权利人后，再补充LICENSE和插件license元数据，并保留第三方许可证。许可证未定不影响本轮本地封装与检查，但对外授权范围需要作者在正式发布时明确。

**升级与重打包**

更新插件清单版本、README、配置辅助脚本中的版本记录及验证记录后再生成新版本，保留既有发行ZIP，不覆盖原有成功结果。分析skill若未变化，可保持其独立版本；插件版本与skill版本分别管理。

打包脚本只用Python标准库：

```text
python -X utf8 scripts/package_release.py --output-dir <插件来源目录之外的新发行位置>
```

它核对已验证状态、原skill文件哈希、文件类型和输出边界，写入发行清单，生成两个ZIP及SHA256，并逐文件核对解压副本与ZIP。不会复制三个工具包、执行分析或修改用户的Codex配置。版本ZIP或解压目的目录已存在时停止，避免覆盖。

本轮实际检查范围见 `VALIDATION.json`。命令行识别、配置辅助脚本检查与用户在GUI中的完整首次使用属于不同证据；未完成的验证会明确标记。
