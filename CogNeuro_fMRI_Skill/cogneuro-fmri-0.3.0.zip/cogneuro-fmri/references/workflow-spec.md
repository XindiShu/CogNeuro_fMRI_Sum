# 交互式 fMRI 分析向导：v0.3 工作约定

本版扫描本地数据、保留来源、提出问题、生成研究计划与 TSV 草稿，并对 `preprocess/preprocess_glm/fc/glm` 提供限定 MATLAB 预检和具体方案获用户确认后的执行。PPI/DCM 等仍只规划。工具包自身能力、skill 调度范围与科研质量分别报告；本轮新增验证面向合成 realign/dummy 路线，segment/smooth 仅接入原生接口，不宣称已有 skill 完整真实数据端到端验证。

## 1. 自适应对话

1. 用户显式调用 `$cogneuro-fmri`，提供数据目录。先确认独立项目目录；项目状态和草稿不得写入输入目录或工具包目录。
2. 运行扫描，报告候选被试、session、run、影像、事件/混杂文件、元数据与 SPM 模型，以及歧义和未知项。候选文件不等于纳入分析的数据。
3. 询问研究目的、范式、希望从何种状态开始和最终终点。根据已有材料提出可选路线，不自动给所有数据套用同一路线。
4. 让用户明确选择 `selected_run_ids`。同一被试不同 session/run 分别保存身份；原始影像与其衍生影像不能无提示地重复纳入。
5. 每轮只问影响下一步的少量问题：先解决路线阻塞项，再讨论方法参数。用户已回答的内容写入状态，后续仅追问新增或矛盾信息。
6. 生成草稿，展示表格映射、事件时间基准、关键参数及理由、尚缺材料。允许用户修改并重新规划。
7. 规划路线交付准备状态及下一步清单。四条已接入路线在补齐结构化执行参数后运行 `prepare`；展示实际预检生成的 `review.md/review.json`，请求用户确认具体方案并等待回答。`preprocess_glm` 另明确说明真实 GLM 设计检查延后到预处理完成后，一次确认覆盖固定四阶段及检查失败停止的规则。取得明确同意后才可 `execute`；宽泛分析意愿不能代替此最终确认。

示例：用户说“做 A 与 B 的激活差异，目录里有预处理后的 BOLD”。向导先核对处理记录与候选 run，确认事件日志是否存在；再问 A/B 的编码、时间零点和比较方向。如果缺少事件时间，输出待补日志清单，不能从“这是记忆任务”推断每个试次的 onset。若用户改为静息 FC，重新检查 FC 所需信息，不继续要求任务事件表。

## 2. 公共身份、处理状态与证据

运行单位至少保留 `run_id`、subject、session、run、task/采集标识及来源文件。缺少 session 可以显式为空；同名 run 必须结合被试、session 和采集标识区分。普通目录无法可靠推断身份时，保留候选并询问，不按目录顺序生成真实身份。

每个字段区分已核实事实、候选判断和未知。文件名 `swra...` 或 `desc-preproc` 只提供线索；不能单独证明平滑、滤波、混杂回归或 dummy 帧删除历史。记录至少覆盖：

- 空间状态：原始/已处理/未知、空间或模板、体素网格、配准和重采样记录。
- 时间状态：帧数、TR、dummy 帧、事件时间基准、滤波、回归、删帧和插值历史。
- 模型状态：SPM 文件存在、是否估计、对应 session、可追溯影像与设计信息。扫描到 `SPM.mat` 不证明模型可用。
- 来源：直接读取的文件/字段、处理记录或用户确认。冲突来源同时保留，直到用户解决。

回答文件按 run 保存事实；模型选择使用相同证据格式：

```json
{
  "independent_unit": "被试；session/run 为重复测量",
  "selected_run_ids": ["扫描实际生成的候选ID"],
  "runs": {
    "扫描实际生成的候选ID": {
      "facts": {
        "temporal_state": {
          "value": "unfiltered_unregressed",
          "source": "用户确认：仅完成空间预处理",
          "confirmed": true
        }
      }
    }
  },
  "parameter_choices": {
    "contrasts": {
      "value": [{"name": "A_minus_B", "weights": [1, -1]}],
      "source": "用户确认的研究假设",
      "confirmed": true
    }
  }
}
```

此片段用于说明证据约定；权重顺序必须对应已确认的 `conditions`。使用当前脚本生成的候选 ID 和实际字段，不将示例文字或数值当作推荐参数。用户确认能确定分析意图，不能替代影像或模型检查。

项目根目录保存 `project.json` 和 `inventory.json`；每轮答案、`plan.json`、`questions.json` 与 `draft_manifests/*.tsv` 保存在 `revisions/000N/`。`project.json` 的 `current_revision` 指向当前修订，旧修订保留；可读取 0.1 项目，新的 `plan` 写入当前版本修订。保存工具版本、参数来源和状态时间；中断后先读状态，再决定是否重新扫描。输入变化后重新核对相关计划，不能沿用过期判断。所有草稿均不改变原始影像、原事件表或工具包正式配置。

命令入口为 skill 自带的 `scripts/fmri_project.py`，使用本机可用 Python；路径由用户提供：

```text
python -X utf8 scripts/fmri_project.py scan --data-root <数据目录> --project-dir <独立项目目录>
python -X utf8 scripts/fmri_project.py plan --project-dir <独立项目目录> --answers <回答JSON文件>
python -X utf8 scripts/fmri_project.py status --project-dir <独立项目目录>
python -X utf8 scripts/fmri_project.py prepare --project-dir <独立项目目录> --matlab-executable <MATLAB程序绝对路径> --spm-root <SPM根目录>
python -X utf8 scripts/fmri_project.py execution-status --project-dir <独立项目目录> [--attempt-id <尝试编号>]
```

## 3. 首批路线与科学决策

| 路线 ID | 希望达到的目标 | 必须确认的关键内容 | v0.3 调度 |
| --- | --- | --- | --- |
| `preprocess` | 原始数据 → 明确停止点的预处理 | 原始 BOLD/T1/采集 JSON、TR、dummy/事件基准、配置 SHA256 和科学参数 | 预检与确认后执行；raw NIfTI、无 SDC、SPM/segmentation |
| `preprocess_glm` | 原始数据 → 选定空间步骤 → 条件 GLM | 预处理全部选择、事件、交接选图、所选空间显式掩膜、运动混杂与 GLM 模型 | 一次具体确认覆盖预处理、交接、真实 GLM 设计预检、GLM 估计 |
| `glm` | 已完成所需空间预处理的 BOLD → 条件 GLM | 未滤波/未回归、显式掩膜、对齐事件与混杂、完整模型选项 | 预检与确认后执行；每 run 独立条件联合模型 |
| `fc` | 已预处理时序 → ROI FC | 未滤波/未回归、静息/任务含义、ROI/掩膜、清理选项和目标连接 | 预检与确认后执行；静态 ROI 矩阵 |
| `ppi` | 已估计任务 SPM 模型 → PPI | 源模型、session、种子、心理对比、经典 PPI 或 gPPI | 仅规划 |
| `task_dcm` | 已估计任务 SPM 模型 → VOI → 任务 DCM | 有序区域、独立 ROI 定义、输入、A/B/C、TR/TE/区域延迟 | 仅规划 |
| `spectral_dcm` | 已预处理静息时序 → 谱 DCM | 静息属性、有序区域、清理历史、A 网络、TR/TE/区域延迟 | 仅规划 |

任意中间步骤续跑、多条分支联合调度、预处理到 FC/DCM 的自动交接、群体推断和其余方法暂未接入；复杂目标写入计划并标记待开发。谱 DCM 不强制先做任务 GLM。GLM 执行限定 canonical HRF、duration 事件、条件联合模型、run 级经典 SPM 与数值 T 对比；不执行 FIR、pmod、LSA/LSS、GLMsingle 或跨 run 合并。

原始路线只接受明确 raw NIfTI，并要求当前配置为 `sdc.method=none`、`segment.backend=spm`、`normalise.method=segmentation`。这是 skill 试点的范围，不代表工具包没有其他算法。`stop_after=realign` 仅完成所选 dummy/STC/头动步骤，仍是部分空间预处理；`segment` 止于结构分割；`smooth` 才沿原生路线继续配准、标准化和平滑。所选步骤和科研目标是否匹配必须在审阅中解释。T1 依原生清单要求提供，包括 realign-only。

采集事实优先来自可信元数据：TR、TE 使用秒；层时间、相位编码和读出时间须保留单位与来源。未知值不能用工具包示例值填成事实。必要时要求用户从扫描协议或原始 JSON 补充。

可推荐的方法参数包括平滑、HRF、混杂、滤波和模型选项；推荐须写出依据与适用条件，并获得确认。不要为尽快完成问答而设立通用最佳参数。对比方向、ROI、网络、输入位置、群体设计是科学决策，应围绕用户假设确认。重复测量不能自动当作独立被试。

执行参数必须有正确的类型和完整字段，见 [execution-profiles.example.json](../assets/execution-profiles.example.json) 及 `scripts/execution.py` 的 `normalized_options`。`questions.json` 的规划问题清零后，仍须收集执行必需项，不能把“推荐默认”一类叙述转换成未经确认的配置。FC 的 `cleaning` 是含 `detrend` 布尔值、`bandHz` 空数组或频带数组、`minResidualDimensions` 正整数的对象；`execution_options` 只含 `max_matrix_gib/roi_min_voxels`。GLM 的条件、对比、`glm_options` 均须结构化，`execution_options` 只含 `max_matrix_gib`；每个 run 需另有已确认的显式 `mask`。

原始路线的 `preprocessing_options` 只含 `stop_after`、`toolkit_config_sha256`、`overrides`。先读当前官方配置并计算真实 SHA256，审阅相关参数后再确认该哈希；`overrides` 为 `{path,value}` 数组，空数组表示明确继承已审阅文件。科学覆盖项限白名单，仅在内存生效，正式配置不变；禁止用执行开关、输入/输出路径或代码字符串作为覆盖项。`preprocess_glm` 合并 GLM 的全部选择，并增加 `handoff_options={bold_source,include_tissue_means:false}`。`bold_source` 可选 `realigned/normalized_unsmoothed/smoothed`，后两者要求 `stop_after=smooth`；掩膜须针对所选产物空间事先确认，不能自动重采样。

事件表只能通过已有记录转换：确认日志列、单位、条件编码、刺激起点和首个保存帧的关系，检查 onset/duration 合法性及扫描覆盖。dummy 帧删除和事件零点必须联动核对。缺少真实时间时保留空白并提出问题；不生成虚构试次。

单独 `glm` 不自动转换日志、平移事件或再删帧。优先提供 `event_reference=retained_first_volume` 的已对齐事件；若声明 `original_first_volume`，仅在已确认 `discard_volumes=0` 时允许执行。原始路线的 dummy 删除只作用于私有影像副本；原生工具包按确认的时间基准生成事件副本。交接核对 `input_info.mat`、dummy 计划和完成记录，确保 onset 仅移动一次、其他事件列及行数保持；负 onset 和原生允许的尾部超界保留并报告。

自动交接从本次完成记录选择 BOLD，生成 24 列运动项及 FD，FD 半径取已执行配置的 `fdRadiusMm`，不从新默认推断；不删行、不滤波、不进行影像混杂回归。首版未提取组织均值，`handoff_options.include_tissue_means` 和后续 `glm_options.confounds.include_tissue_means` 都必须为 false。单独 GLM 使用用户提供的真实混杂表时，仍按已确认的可用列检查。

## 4. 预检、审阅与执行状态

`prepare` 为每次尝试建立 `execution/000N/`，输入复制到其中，gzip 仅在私有副本解压；用固定入口和独立 MATLAB 进程实际检查。FC 评估掩膜内全时序、清理投影、ROI 覆盖与相关估计；已有输入的 GLM 逐帧检查掩膜内值及网格/TR，建立真实 SPM 设计，检查高通、混杂与对比可估计性，不估计 beta。原始路线此时检查原始影像、采集事实和原生处理计划，不运行预处理步骤。矩阵预算单位 GiB，频带单位 Hz；预算约束不保证进程峰值内存。

`preprocess_glm` 的真实 GLM 输入尚未生成，因此初次 `review.json` 中明确列出 deferred checks。审阅必须展示固定四阶段、交接选图/事件/混杂/掩膜规则、所有 GLM 参数和失败停止策略；不能声称实际设计已经验证。用户的一次具体确认覆盖此有条件的四阶段方案。确认后依次执行：

1. 原生预处理，核对真实完成标记和必需输出。
2. 基于完成记录交接，核对身份、保留帧/TR、一次事件移位、运动混杂及显式掩膜。
3. 对实际交接数据建立 SPM 设计，验证高通后残差维度及对比可估计性。
4. 仅在前述检查通过后按已确认参数估计条件 GLM，并核对工程产物。

各阶段使用隔离 MATLAB 进程；检查通过且方案不变时无需重复请求同一确认。任一步失败均停止，保留先前成功和部分结果；不自行改参数、选图或补造材料。改变方案后须新修订、预检和审阅。

预检后冻结源文件、私有副本、清单、计划/答案、辅助程序、MATLAB 启动程序和工具包/SPM 的 `.m/.p/MEX` 指纹。不是完整软件环境镜像。生成 `review.json/review.md` 后，先完整读取并展示数据、目标、参数/来源、实际检查与限制，再向用户请求对此版本的最终执行确认。用户同意前不得调用：

```text
python -X utf8 scripts/fmri_project.py execute --project-dir <独立项目目录> --attempt-id <已审阅尝试编号> --review-digest <review.json的SHA256> --confirmation 确认执行
```

短语是调用方在实际获得同意后填写的规范化断言；它不验证用户身份，也不能替代对话中的同意。计划更新、文件变化或尝试编号不同均不能沿用旧确认。

| 阶段 | 含义与下一步 |
| --- | --- |
| `draft_prepared` | 规划问题已回答，尚未完成实际预检 |
| `preflight_failed` | 预检失败，保留证据；修正问题后建立新尝试 |
| `awaiting_confirmation` | 本次预检通过；展示审阅文件及明确延后检查项，等待对此具体方案的确认 |
| `invalidated` / `needs_new_preflight` | 冻结方案或关联修订变化，须新预检与审阅 |
| `running_or_interrupted` | 不能确认后台是否仍运行；查进程、日志及结果，不自动重试 |
| `execution_failed` | 执行失败，保留部分产物；不能原地自动重跑 |
| `complete` | 工程产物与凭据已核查，科研质量仍待验收 |
| `outputs_changed` | 完成后产物缺失/大小改变，或凭据改变，需核实 |

`execution_ready` 保持 false，避免把规划或预检状态视为自动授权。实际执行同时要求正确阶段、匹配摘要与人类同意。`status` 恢复规划；`execution-status` 只读执行情况。完成凭据保留输出 SHA256；常规状态查询只检查凭据、产物存在和大小，不重算全部影像哈希。不删除失败目录，不自动清理后重试，也不承诺恢复半成品。

## 5. 验收与后续里程碑

准备完成需满足：选中运行身份唯一；输入来源明确；所选路线的必要材料和科学决策已确认；草稿列结构及路径映射可检查；矛盾和缺项清零或明确阻塞。准备完成只代表可进入更深预检，不代表可以直接估计或科研质量通过。

验证分三层：文件/头信息可读与结构一致；体素有限性、时间/网格及变换检查；科研 QC、设计可估计性、模型拟合与结论边界。前一层通过不能代替后一层。

独立验收场景至少包括：

- 两被试 × 两 session × 两 run，不丢失重复测量身份，不将 session 当作独立被试。
- 原始/已预处理/只有 SPM 的混合目录；明确选中子集，不能全自动纳入或重复处理。
- 同一 BOLD 多个事件/混杂候选；保留歧义并阻塞，不任选第一项。
- 缺事件、未知时间零点、毫秒日志；正确提出补充项和单位确认。
- 只有文件名前缀、缺处理记录；保持处理状态未知，防止重复滤波/回归/平滑。
- JSON 与用户答案矛盾、移走文件、修改输入后恢复；重新核对受影响内容。
- PPI/任务 DCM 只有 `SPM.mat`；保留候选，不能声称已估计或可提取 VOI。
- 静息谱 DCM；不要求无关的任务事件/任务 GLM，不默认网络和 TE。
- 只读输入目录、中断后继续、重复运行规划；原输入和成功结果保持原状。

当前已接入 FC/条件 GLM，以及限定原始预处理和预处理到 GLM 的隔离调度。新增原生 segment/smooth 接口不等于该 skill 已完成相应真实数据验证；本轮新增合成验收针对 realign/dummy 及完成记录交接，实际通过数量以随包验证记录为准。后续完善其他预处理分支、PPI/DCM、按入口能力设计的恢复与限定真实数据验证。每阶段分别报告接口实现、合成测试、真实数据范围和未完成项；不能把工具包原有真实数据结果算作 skill 端到端验证。
