# 工具包适配边界与执行前交接

本文件供 skill 决策时按需读取。v0.2 已接入 `fc/glm` 的实际 MATLAB 预检和用户确认后的执行；预处理、PPI、DCM 等仍只规划。工具包原有测试和限定真实数据验证不能充当 skill 端到端验证；本版尚无真实参与者数据的端到端验证。

## 安装位置与路径隔离

用户提供预处理、GLM、分析方法包的安装根目录，以及本机 MATLAB 程序绝对路径和 SPM 根目录；按所选路线检查依赖，不把开发机器的盘符或 HCP 目录设为默认。缺少 MATLAB 时可继续盘点与规划，但不能声称已完成实际预检。

预处理与 GLM 使用共享 `+psy` 命名空间及部分同名函数。当前适配器使用独立 MATLAB 进程，加入所选包的明确目录及 SPM，并核对实际加载来源；禁止无差别 `addpath(genpath(...))` 后假定加载正确。Python 以参数列表、`shell=false` 和固定 MATLAB job 入口启动进程。官方配置只读入内存，通过本次配置对象和私有清单传参，不覆盖任何正式 `toolkit_config.m` 或其他配置。

## 各入口的真实边界

| 包与入口 | 已有接口行为 | skill 当前检查或待补项 |
| --- | --- | --- |
| 预处理 `psy.preprocess_batch(cfg)` | `execute=false` 可预检并写项目侧检查结果；`stopAfter` 限 `realign/segment/smooth`；`inputStage=preprocessed` 执行会拒绝 | 检查起点支持、采集/结构/校正材料；区分预检输出与成功影像；逐阶段读取完成记录 |
| GLM `psy.glm_batch(cfg)` | 含 `model` 配置时进入 `psy.glm_framework_batch`；要求新的输出根目录；工具包准备模式本身不等于设计可估计性检查 | 本版额外逐帧检查显式掩膜/网格/TR、事件/混杂，建立真实 SPM 设计，检查高通、设计秩及对比可估计性；确认后才估计 |
| 分析方法 `run_prepare_inputs(cfg)` | 显式清单适配，不做通用 BIDS 发现或自动重采样；`execute=false` 是较浅预检；当前影像入口要求解压 `.nii` | FC 已另接实际预检及私有副本解压；其他方法的深度检查与调度未接入，不能沿用浅预检声称全验证 |
| ROI FC `run_function(cfg)` | 使用 `static_fc`、显式 ROI 和清理选项；独立 run 生成静态相关矩阵 | 本版使用生产函数预检掩膜内时序/网格/TR、联合投影、ROI 覆盖、数值方差和估计器；确认后调用生产入口并核查产物 |
| PPI `run_ppi` / `run_ppi_batch` | 使用已有任务 SPM、种子、session 和心理模型信息 | 检查源模型估计与引用文件、session 对应、种子独立性、经典 PPI/gPPI 所需编码 |
| 任务 DCM `cog.prepare_dcm_spm` → `cog.dcm_build` | 从已有任务 SPM 在私有输出提取 VOI/高分辨率输入；构建显式区域、时间信息和 A/B/C 模型 | 有序 ROI/网格、源模型文件链、TE 来源、输入覆盖、A/B/C 与区域/条件对应，另行检查反演质量 |
| 谱 DCM `cog.dcm_build(...,'spectral',...)` | 使用静息区域时序与 A 网络；无任务 B/C；需 TR、TE 和区域延迟 | 静息及清理记录、区域顺序、长度/AR 设置、充分反演与拟合评估；不经过任务 VOI 流程 |

`cog.dcm_build` 当前对 TE 的接口约束为秒且 `(0, 0.1]`，区域延迟范围为 `[0, TR]`；这些是代码约束，不是推荐默认值。任务输入需覆盖完整扫描并使用与 TR 相容的时间网格。`prepare_dcm_spm` 会从 SPM microtime 设置计算区域延迟，因此应展示该来源及适用性，不能把它误写为扫描仪实测层时间。

SPM 文件出现只建立候选；其估计状态、设计、引用影像、beta/残差、对比和 session 均需 MATLAB 深度检查。PPI 与任务 DCM 可以先生成问题和草稿，但缺这些检查时不能进入执行。谱 DCM 的有限后验或任务 DCM 的成功返回也不能直接证明收敛或模型质量。

## v0.2 的执行配置与限制

执行配置以 `scripts/execution.py` 的 `normalized_options` 为准，形状示例见 [execution-profiles.example.json](../assets/execution-profiles.example.json)。其中的示例数值不是推荐默认值。所有 `parameter_choices` 均需实际来源、`confirmed=true` 和正确类型；缺字段、未知键及叙述性配置不能自动替换为默认。

| 路线 | 必须确认的执行选择 | 限定范围 |
| --- | --- | --- |
| FC | `cleaning={detrend,bandHz,minResidualDimensions}`；`fc_measure`；`roi_definition`；`execution_options={max_matrix_gib,roi_min_voxels}` | `detrend` 为布尔；频带为 `[]` 或 `[低频,高频]` Hz，且在各 run Nyquist 范围内；残差维数与 ROI 最少体素为正整数；估计器 pearson/spearman/partial |
| GLM | `conditions` 名称数组；`contrasts` 的 name/数值 weights 数组；完整 `glm_options`；`execution_options={max_matrix_gib}` | canonical HRF、duration 事件、条件联合模型、每 run 独立经典 SPM、AR(1)/FAST、T 对比；不含 pmod/FIR/LSA/LSS/GLMsingle/跨 run 或群体模型 |

GLM 的 `glm_options` 明确包含 `highpass_seconds`、`microtime_resolution`、`microtime_onset`、`serial_correlation`、`hrf`、`min_residual_df`、`mask_threshold`、`confounds`。其 `confounds` 明确包含 `motion_model`、`include_tissue_means`、`linear_trend`、`add_spikes`、`fd_threshold_mm`、`min_residual_df`；不能因关闭某项就省略其字段。条件和对比名须符合脚本标识约束，权重顺序与条件数组对应，不得无记录地更改原事件标签。

两条执行路线均要求声明为 `unfiltered_unregressed` 的空间预处理输入；该声明需处理记录或用户确认，不能由影像推断。FC 需显式 mask/ROI；GLM 每个 run 另需已确认的显式 mask、真实 confounds 和已对齐事件。GLM 规划清单的问题清零不会自动补齐其执行 mask 和结构化选项，向导必须继续询问。

本版不重采样、不删帧、不自动转换日志或平移事件。GLM 的 `retained_first_volume` 表示事件对齐当前输入；若仍声明 `original_first_volume`，只允许 `discard_volumes=0`。来源不清或需要时间转换时先停止该路线，要求补充可追溯材料。矩阵预算单位为 GiB，只限制所检查数组，不能视作 MATLAB 进程峰值保证。掩膜内有限性和相同网格不证明解剖对齐、合理覆盖或科研质量。

## 清单与跨包交接

`draft_manifests/*.tsv` 为供审核的草稿；存在未确认、缺失或冲突字段时禁止送入工具包。`prepare` 从当前确认的计划另建私有 `runs.tsv`，不直接执行草稿。当前支持的列和字段以安装版本的读表函数/模板为准，不通过修改核心计算函数适配单个数据集。

- 预处理 → GLM：从本次实际完成记录提取每个 run 的最终 BOLD、空间/平滑状态、保留帧范围、事件与混杂映射。确认事件零点后再交接；不靠前缀拼接路径。
- 预处理 → FC/谱 DCM：区分空间处理与时间清理，记录所有滤波、回归、删帧历史。已经清理的时序不能隐式再次加入混杂。
- GLM → PPI/任务 DCM：保留源 `SPM.mat`、session 索引、ROI 来源和对应条件；私有输出中准备新的模型/VOI，不改源 SPM。
- 多 run：每行对应明确运行单位。原始与衍生候选、同一 SPM 的多个 session 不能混为一个 run；未来模型合并必须有显式层级设计。

上述跨包交接仍属待接入功能；本版不能自动从原始数据运行到 FC/DCM。多 run 的 FC/GLM 批次分别保存 run 级结果，不隐式进行统计合并。

所有新结果写独立项目下的本次 `execution/000N/results`，已有目录会被拒绝。源输入仅复制，`.nii.gz` 在本次私有目录解压；原文件和成功结果保留。本版不自动复用其他输出或恢复半成品；不可将“目录已存在”解释为成功，不删除失败目录后掩盖历史。

## 执行确认、指纹与验收

入口顺序为 `prepare` → 展示 `review.md/review.json` → 等待用户明确确认 → `execute`。审阅方案列出纳入 run、范式/目标、关键参数和来源、实际预检、软件来源、输出位置、资源约束和边界。此前要求分析或开发的宽泛请求不替代对具体真实数据方案的同意；不得由向导自行批准。

`execute` 必须同时传入匹配的 `attempt_id`、`review_digest` 与精确的 `--confirmation 确认执行`。短语是实际获得用户同意后的规范化记录，不构成身份认证。源/私有输入、清单、计划/答案、MATLAB 启动程序、Python 辅助程序及工具包/SPM 的 `.m/.p/MEX` 均纳入指纹；这不是完整环境镜像。方案变化后须新预检和重新审阅。

预检失败、执行失败或失效的目录均保留；进程中断后 `execution-status` 报告 `running_or_interrupted`，不假定后台已停，也不自动再执行。待确认状态重新核对冻结输入与完整代码清单，包括私有适配器目录；该查询可能读取完整影像。`complete` 后凭据保存输出 SHA256；完成状态查询核查凭据以及产物存在和大小，不重新哈希全部影像，科研质量仍为未通过。原始数据盘离线不会阻止读取本地完成结果，会单列 `source_available=false`。

适配器验收至少包含配置/清单错误提前拒绝、独立合成数据测试、跨包身份和时间交接、路径冲突检查、中断隔离、完成记录及重新运行保护。真实数据另列范围，逐项引用工具包当前验证记录/方法状态，不能把有限工程样例外推为所有协议或科研结论。

不下载参与者数据、不自动变更软件安装、不做群体统计或自动发表结论。预处理/PPI/DCM 调度、完整跨阶段恢复、真实数据端到端验证及研究相关 QC 均仍待完成。工程预检及运行成功不能代替模型诊断与科学解释。
